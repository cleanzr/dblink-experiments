## Description
Three datafiles (A, B, C) containing information on a population of 400,000 
employees. The datafiles are included in a single CSV file.

## Attributes
* RECID: identifier for the record, string, e.g. `A003450`
* FILEID: identifier for the file, string, e.g. `A`
* ENTID: identifier for the employee associated with the record, integer.
* SA1: statistical area level 1, integer, e.g. `10981`
* MB: mesh block, integer, e.g. `1010321`
* BDAY: day of the year, integer,  on interval `[1,366]`
* BYEAR: year, integer, on interval `[1946,2000]`
* SEX: male or female, integer, in the set `{1, 2}`
* INDUSTRY: , integer, in the set `{1,2,3,4,5}`
* CASUAL: whether employment is on a casual basis, boolean, `{0,1}`
* FULLTIME: whether employment is full-time, boolean, `{0,1}`
* HOURS: hours worked per week, integer, on interval `[1,45]`
* PAYRATE: AUD per hour, float, on interval `[26.25,54]`
* AWE: average weekly earnings, float, on interval `[34.44, 2354]`

## Files
Although all of the attributes are included in all files, since the 
data is generated synthetically, in practice some of the attributes 
may be missing.

The following is a realistic scenario, which highlights the need for 
data linkage.

| File | Description                                 | Size   | Missing variables            |
|------|---------------------------------------------|--------|------------------------------|
| A    | supplementary survey of permanent employees | 120000 | CASUAL, HOURS, FULLTIME, AWE |
| B    | supplementary survey of all employees       | 180000 | PAYRATE, FULLTIME, AWE       |
| C    | census of all employees                     | 360000 | PAYRATE, HOURS, CASUAL       | 

## Missing values
Some values are missing. They are represented by a '.' character.

# Licence
Copyright 2018 Australian Bureau of Statistics
